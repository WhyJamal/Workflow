"use client";

import { useState, useRef, useCallback, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  createWork,
  deleteWork,
  toggleWorkLike,
  type WorkWithDetails,
} from "@/actions/work.actions";
import Image from "next/image";

// ─── Types ──────────────────────────────────────────────────────────────────

type MediaPreview = {
  file: File;
  previewUrl: string;
  type: "IMAGE" | "VIDEO";
  uploadedUrl?: string;
};

// ─── Icons (inline SVG) ──────────────────────────────────────────────────────

function HeartIcon({ filled }: { filled?: boolean }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill={filled ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  );
}

function GridIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" />
      <rect x="3" y="14" width="7" height="7" /><rect x="14" y="14" width="7" height="7" />
    </svg>
  );
}

function FeedIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="3" width="18" height="5" rx="1" /><rect x="3" y="10" width="18" height="5" rx="1" /><rect x="3" y="17" width="18" height="5" rx="1" />
    </svg>
  );
}

function TrashIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <polyline points="3,6 5,6 21,6" /><path d="M19,6l-1,14H6L5,6M10,11v6M14,11v6M9,6V4h6v2" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
      <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}

function ChevronIcon({ direction }: { direction: "left" | "right" }) {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
      {direction === "left" ? <polyline points="15,18 9,12 15,6" /> : <polyline points="9,18 15,12 9,6" />}
    </svg>
  );
}

function MapPinIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 1 1 18 0z" /><circle cx="12" cy="10" r="3" />
    </svg>
  );
}

function VideoPlayIcon() {
  return (
    <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
      <polygon points="5,3 19,12 5,21 5,3" />
    </svg>
  );
}

// ─── Avatar ─────────────────────────────────────────────────────────────────

function Avatar({ name, image, size = 40 }: { name?: string | null; image?: string | null; size?: number }) {
  const initials = (name ?? "U").split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
  if (image) {
    return (
      <div className="rounded-full overflow-hidden shrink-0 ring-2 ring-emerald-500/30" style={{ width: size, height: size }}>
        <img src={image} alt={name ?? ""} className="w-full h-full object-cover" />
      </div>
    );
  }
  return (
    <div
      className="rounded-full bg-linear-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-bold shrink-0"
      style={{ width: size, height: size, fontSize: size * 0.35 }}
    >
      {initials}
    </div>
  );
}

// ─── Media Carousel ──────────────────────────────────────────────────────────

function MediaCarousel({ media }: { media: WorkWithDetails["media"] }) {
  const [index, setIndex] = useState(0);
  if (media.length === 0) return null;

  const current = media[index];
  return (
    <div className="relative aspect-square bg-zinc-900 overflow-hidden">
      {current.type === "VIDEO" ? (
        <video
          src={current.url}
          className="w-full h-full object-cover"
          controls
          playsInline
          preload="metadata"
        />
      ) : (
        <img src={current.url} alt="" className="w-full h-full object-cover" />
      )}

      {/* Navigation */}
      {media.length > 1 && (
        <>
          {index > 0 && (
            <button
              onClick={() => setIndex((i) => i - 1)}
              className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/50 backdrop-blur flex items-center justify-center text-white hover:bg-black/70 transition-colors"
            >
              <ChevronIcon direction="left" />
            </button>
          )}
          {index < media.length - 1 && (
            <button
              onClick={() => setIndex((i) => i + 1)}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/50 backdrop-blur flex items-center justify-center text-white hover:bg-black/70 transition-colors"
            >
              <ChevronIcon direction="right" />
            </button>
          )}
          {/* Dots */}
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1">
            {media.map((_, i) => (
              <button
                key={i}
                onClick={() => setIndex(i)}
                className={`rounded-full transition-all ${i === index ? "w-4 h-1.5 bg-white" : "w-1.5 h-1.5 bg-white/50"}`}
              />
            ))}
          </div>
        </>
      )}

      {/* Video badge */}
      {current.type === "VIDEO" && (
        <div className="absolute top-2 right-2 bg-black/60 backdrop-blur rounded px-1.5 py-0.5 text-xs text-white font-medium">
          VIDEO
        </div>
      )}
    </div>
  );
}

// ─── Grid Thumbnail ──────────────────────────────────────────────────────────

function GridThumbnail({
  work,
  onClick,
  isOwn,
  onDelete,
}: {
  work: WorkWithDetails;
  onClick: () => void;
  isOwn: boolean;
  onDelete: () => void;
}) {
  const first = work.media[0];
  const [deleting, startDelete] = useTransition();

  return (
    <div className="relative group aspect-square bg-zinc-100 dark:bg-zinc-900 overflow-hidden rounded-sm cursor-pointer" onClick={onClick}>
      {first?.type === "VIDEO" ? (
        <div className="w-full h-full bg-zinc-800 flex items-center justify-center">
          <VideoPlayIcon />
        </div>
      ) : first ? (
        <img src={first.url} alt="" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
      ) : (
        <div className="w-full h-full bg-zinc-200 dark:bg-zinc-800" />
      )}

      {/* Overlay on hover */}
      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3 text-white text-sm font-semibold">
        <span className="flex items-center gap-1">
          <HeartIcon filled /> {work._count.likes}
        </span>
        {work.media.length > 1 && (
          <span className="flex items-center gap-1 text-xs bg-black/50 px-2 py-1 rounded-full">
            1/{work.media.length}
          </span>
        )}
      </div>

      {/* Delete button for owner */}
      {isOwn && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
          disabled={deleting}
          className="absolute top-1.5 right-1.5 w-7 h-7 rounded-full bg-black/60 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500/80"
        >
          <TrashIcon />
        </button>
      )}
    </div>
  );
}

// ─── Work Card (Feed) ────────────────────────────────────────────────────────

function WorkCard({
  work,
  currentUserId,
  onDelete,
}: {
  work: WorkWithDetails;
  currentUserId: string | null;
  onDelete: (id: string) => void;
}) {
  const [liked, setLiked] = useState(work.isLiked);
  const [likes, setLikes] = useState(work._count.likes);
  const [pending, startTransition] = useTransition();
  const isOwn = currentUserId === work.author.id;

  function handleLike() {
    if (!currentUserId) return;
    const wasLiked = liked;
    setLiked(!wasLiked);
    setLikes((l) => (wasLiked ? l - 1 : l + 1));
    startTransition(async () => {
      await toggleWorkLike(work.id);
    });
  }

  const timeAgo = (() => {
    const diff = Date.now() - new Date(work.createdAt).getTime();
    const h = Math.floor(diff / 3600000);
    const d = Math.floor(h / 24);
    if (d > 0) return `${d} kun oldin`;
    if (h > 0) return `${h} soat oldin`;
    return "Hozirgina";
  })();

  return (
    <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <Avatar name={work.author.name} image={work.author.image} size={38} />
          <div>
            <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-100 leading-none">
              {work.author.name ?? "Foydalanuvchi"}
            </p>
            {work.author.masterProfile?.title && (
              <p className="text-xs text-zinc-400 mt-0.5">{work.author.masterProfile.title}</p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-zinc-400">{timeAgo}</span>
          {isOwn && (
            <button
              onClick={() => onDelete(work.id)}
              className="w-7 h-7 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center justify-center text-zinc-400 hover:text-red-500 transition-colors"
            >
              <TrashIcon />
            </button>
          )}
        </div>
      </div>

      {/* Location */}
      {work.location && (
        <div className="px-4 pb-2 flex items-center gap-1 text-xs text-zinc-400">
          <MapPinIcon />
          {work.location}
        </div>
      )}

      {/* Media */}
      <MediaCarousel media={work.media} />

      {/* Actions */}
      <div className="px-4 pt-3 pb-1">
        <button
          onClick={handleLike}
          disabled={!currentUserId || pending}
          className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${
            liked
              ? "text-red-500"
              : "text-zinc-500 dark:text-zinc-400 hover:text-red-400"
          }`}
        >
          <HeartIcon filled={liked} />
          <span>{likes} ta like</span>
        </button>
      </div>

      {/* Caption */}
      {work.caption && (
        <div className="px-4 pb-4 pt-1.5">
          <p className="text-sm text-zinc-700 dark:text-zinc-300 leading-relaxed">{work.caption}</p>
        </div>
      )}
    </div>
  );
}

// ─── Upload Modal ────────────────────────────────────────────────────────────

function UploadModal({
  onClose,
  onSuccess,
}: {
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [previews, setPreviews] = useState<MediaPreview[]>([]);
  const [caption, setCaption] = useState("");
  const [location, setLocation] = useState("");
  const [uploading, setUploading] = useState(false);
  const [posting, startPosting] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFiles = useCallback((files: FileList | null) => {
    if (!files) return;
    const newPreviews: MediaPreview[] = Array.from(files).map((file) => {
      const isVideo = file.type.startsWith("video/");
      return {
        file,
        previewUrl: URL.createObjectURL(file),
        type: isVideo ? "VIDEO" : "IMAGE",
      };
    });
    setPreviews((prev) => [...prev, ...newPreviews].slice(0, 10));
  }, []);

  function removePreview(i: number) {
    setPreviews((prev) => prev.filter((_, idx) => idx !== i));
  }

  async function handleSubmit() {
    if (previews.length === 0) {
      setError("Kamida bitta rasm yoki video tanlang");
      return;
    }
    setError(null);
    setUploading(true);

    try {
      // Upload all files
      const uploaded = await Promise.all(
        previews.map(async (p, i) => {
          const fd = new FormData();
          fd.append("file", p.file);
          const res = await fetch("/api/upload", { method: "POST", body: fd });
          if (!res.ok) {
            const err = await res.json();
            throw new Error(err.error ?? "Yuklashda xatolik");
          }
          const data = await res.json();
          return { url: data.url, type: data.type as "IMAGE" | "VIDEO", order: i };
        })
      );

      setUploading(false);

      startPosting(async () => {
        await createWork({ caption: caption.trim() || undefined, location: location.trim() || undefined, media: uploaded });
        onSuccess();
        onClose();
      });
    } catch (err: any) {
      setUploading(false);
      setError(err.message ?? "Xatolik yuz berdi");
    }
  }

  const isLoading = uploading || posting;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-zinc-900 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-200 dark:border-zinc-800">
          <h2 className="font-bold text-zinc-900 dark:text-zinc-100 text-lg">Yangi ish joylash</h2>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 text-2xl leading-none">&times;</button>
        </div>

        <div className="p-5 space-y-4">
          {/* Drop zone */}
          <div
            onClick={() => fileRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => { e.preventDefault(); handleFiles(e.dataTransfer.files); }}
            className="border-2 border-dashed border-zinc-300 dark:border-zinc-700 rounded-xl p-6 text-center cursor-pointer hover:border-emerald-500 transition-colors"
          >
            <div className="text-4xl mb-2">📸</div>
            <p className="text-sm font-medium text-zinc-700 dark:text-zinc-300">Rasm yoki video tanlang</p>
            <p className="text-xs text-zinc-400 mt-1">JPEG, PNG, WebP, GIF, MP4, WebM, MOV · Max 10 ta</p>
          </div>

          <input
            ref={fileRef}
            type="file"
            multiple
            accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime"
            className="hidden"
            onChange={(e) => handleFiles(e.target.files)}
          />

          {/* Previews */}
          {previews.length > 0 && (
            <div className="grid grid-cols-5 gap-2">
              {previews.map((p, i) => (
                <div key={i} className="relative aspect-square rounded-lg overflow-hidden bg-zinc-100 dark:bg-zinc-800">
                  {p.type === "VIDEO" ? (
                    <div className="w-full h-full bg-zinc-700 flex items-center justify-center">
                      <span className="text-white text-xl">▶</span>
                    </div>
                  ) : (
                    <img src={p.previewUrl} alt="" className="w-full h-full object-cover" />
                  )}
                  <button
                    onClick={() => removePreview(i)}
                    className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-black/70 text-white text-xs flex items-center justify-center hover:bg-red-500 transition-colors"
                  >
                    ×
                  </button>
                </div>
              ))}
              {previews.length < 10 && (
                <button
                  onClick={() => fileRef.current?.click()}
                  className="aspect-square rounded-lg border-2 border-dashed border-zinc-300 dark:border-zinc-700 flex items-center justify-center text-zinc-400 hover:border-emerald-500 hover:text-emerald-500 transition-colors"
                >
                  <PlusIcon />
                </button>
              )}
            </div>
          )}

          {/* Caption */}
          <textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="Tavsif yozing... (ixtiyoriy)"
            rows={3}
            className="w-full text-sm border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 py-2.5 bg-zinc-50 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 placeholder-zinc-400 resize-none focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
          />

          {/* Location */}
          <div className="flex items-center gap-2 border border-zinc-200 dark:border-zinc-700 rounded-xl px-3 py-2.5 bg-zinc-50 dark:bg-zinc-800">
            <MapPinIcon />
            <input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Joylashuv (ixtiyoriy)"
              className="flex-1 bg-transparent text-sm text-zinc-800 dark:text-zinc-200 placeholder-zinc-400 focus:outline-none"
            />
          </div>

          {error && (
            <div className="text-sm text-red-500 bg-red-50 dark:bg-red-900/20 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={isLoading || previews.length === 0}
            className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold transition-colors flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.4 0 0 5.4 0 12h4z" />
                </svg>
                {uploading ? "Yuklanmoqda..." : "Joylashtirilmoqda..."}
              </>
            ) : (
              "Joylash"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Work Detail Modal ───────────────────────────────────────────────────────

function WorkDetailModal({
  work,
  onClose,
  currentUserId,
  onDelete,
}: {
  work: WorkWithDetails;
  onClose: () => void;
  currentUserId: string | null;
  onDelete: (id: string) => void;
}) {
  const [liked, setLiked] = useState(work.isLiked);
  const [likes, setLikes] = useState(work._count.likes);
  const [pending, startTransition] = useTransition();
  const isOwn = currentUserId === work.author.id;

  function handleLike() {
    if (!currentUserId) return;
    const wasLiked = liked;
    setLiked(!wasLiked);
    setLikes((l) => (wasLiked ? l - 1 : l + 1));
    startTransition(async () => { await toggleWorkLike(work.id); });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" onClick={onClose}>
      <div
        className="bg-white dark:bg-zinc-900 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col sm:flex-row shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Media side */}
        <div className="sm:w-1/2 shrink-0 bg-black">
          <MediaCarousel media={work.media} />
        </div>

        {/* Info side */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-zinc-200 dark:border-zinc-800">
            <div className="flex items-center gap-3">
              <Avatar name={work.author.name} image={work.author.image} size={36} />
              <div>
                <p className="text-sm font-semibold">{work.author.name ?? "Foydalanuvchi"}</p>
                {work.author.masterProfile?.title && (
                  <p className="text-xs text-zinc-400">{work.author.masterProfile.title}</p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              {isOwn && (
                <button
                  onClick={() => { onDelete(work.id); onClose(); }}
                  className="text-zinc-400 hover:text-red-500 p-1 rounded transition-colors"
                >
                  <TrashIcon />
                </button>
              )}
              <button onClick={onClose} className="text-zinc-400 hover:text-zinc-600 text-2xl leading-none">&times;</button>
            </div>
          </div>

          {/* Caption / location */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {work.location && (
              <p className="flex items-center gap-1 text-xs text-zinc-400">
                <MapPinIcon /> {work.location}
              </p>
            )}
            {work.caption && (
              <p className="text-sm text-zinc-700 dark:text-zinc-300 leading-relaxed">{work.caption}</p>
            )}
          </div>

          {/* Like bar */}
          <div className="p-4 border-t border-zinc-200 dark:border-zinc-800 flex items-center gap-3">
            <button
              onClick={handleLike}
              disabled={!currentUserId || pending}
              className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${
                liked ? "text-red-500" : "text-zinc-500 hover:text-red-400"
              }`}
            >
              <HeartIcon filled={liked} />
              {likes}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main Component ──────────────────────────────────────────────────────────

export function WorksClient({
  works: initialWorks,
  currentUserId,
  currentUserRole,
}: {
  works: WorkWithDetails[];
  currentUserId: string | null;
  currentUserRole: string | null;
}) {
  const [works, setWorks] = useState(initialWorks);
  const [view, setView] = useState<"feed" | "grid">("feed");
  const [showUpload, setShowUpload] = useState(false);
  const [selected, setSelected] = useState<WorkWithDetails | null>(null);
  const [, startDelete] = useTransition();
  const router = useRouter();

  const isMaster = currentUserRole === "MASTER";

  function handleDelete(id: string) {
    setWorks((prev) => prev.filter((w) => w.id !== id));
    startDelete(async () => {
      await deleteWork(id);
    });
  }

  function handleSuccess() {
    router.refresh();
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-zinc-900 dark:text-zinc-100">Ishlar</h1>
          <p className="text-sm text-zinc-400 mt-0.5">Masterlarning eng yaxshi ishlari</p>
        </div>
        <div className="flex items-center gap-2">
          {/* View toggle */}
          <div className="flex bg-zinc-100 dark:bg-zinc-800 rounded-lg p-0.5">
            <button
              onClick={() => setView("feed")}
              className={`p-2 rounded-md transition-colors ${view === "feed" ? "bg-white dark:bg-zinc-700 shadow-sm text-zinc-900 dark:text-zinc-100" : "text-zinc-400"}`}
            >
              <FeedIcon />
            </button>
            <button
              onClick={() => setView("grid")}
              className={`p-2 rounded-md transition-colors ${view === "grid" ? "bg-white dark:bg-zinc-700 shadow-sm text-zinc-900 dark:text-zinc-100" : "text-zinc-400"}`}
            >
              <GridIcon />
            </button>
          </div>

          {/* Upload button — only for masters */}
          {isMaster && (
            <button
              onClick={() => setShowUpload(true)}
              className="flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold px-4 py-2.5 rounded-xl transition-colors"
            >
              <PlusIcon /> Qo'shish
            </button>
          )}
        </div>
      </div>

      {/* Empty state */}
      {works.length === 0 && (
        <div className="text-center py-20">
          <div className="text-5xl mb-4">🖼️</div>
          <h3 className="text-lg font-semibold text-zinc-700 dark:text-zinc-300 mb-1">Hali ishlar yo'q</h3>
          <p className="text-sm text-zinc-400">
            {isMaster ? "Birinchi bo'lib o'z ishingizni joylashtiring!" : "Masterlar hali ish joylamagan"}
          </p>
          {isMaster && (
            <button
              onClick={() => setShowUpload(true)}
              className="mt-4 px-6 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold rounded-xl transition-colors"
            >
              Ish joylash
            </button>
          )}
        </div>
      )}

      {/* Feed view */}
      {view === "feed" && works.length > 0 && (
        <div className="space-y-5">
          {works.map((w) => (
            <WorkCard key={w.id} work={w} currentUserId={currentUserId} onDelete={handleDelete} />
          ))}
        </div>
      )}

      {/* Grid view */}
      {view === "grid" && works.length > 0 && (
        <div className="grid grid-cols-3 gap-1">
          {works.map((w) => (
            <GridThumbnail
              key={w.id}
              work={w}
              onClick={() => setSelected(w)}
              isOwn={currentUserId === w.author.id}
              onDelete={() => handleDelete(w.id)}
            />
          ))}
        </div>
      )}

      {/* Modals */}
      {showUpload && (
        <UploadModal onClose={() => setShowUpload(false)} onSuccess={handleSuccess} />
      )}
      {selected && (
        <WorkDetailModal
          work={selected}
          onClose={() => setSelected(null)}
          currentUserId={currentUserId}
          onDelete={handleDelete}
        />
      )}
    </div>
  );
}